document.addEventListener("DOMContentLoaded", function () {
    console.log("Dashboard Loaded ✅");

    // LOGIN HANDLING
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function (e) {
            e.preventDefault();

            const role = document.getElementById("role").value;
            const email = document.getElementById("email").value.trim();
            const password = document.getElementById("password").value.trim();

            const validCredentials = {
                admin: { email: "admin@example.com", password: "1234" },
                event_organizer: { email: "organizer@example.com", password: "1234" },
                attendee: { email: "attendee@example.com", password: "1234" },
                guest: { email: "guest@example.com", password: "1234" }
            };

            const credentials = validCredentials[role];

            if (credentials && credentials.email === email && credentials.password === password) {
                localStorage.setItem("loggedIn", "true");
                localStorage.setItem("role", role);

                if (role === "admin") {
                    window.location.href = "admin.html";
                } else if (role === "event_organizer") {
                    window.location.href = "event_organizer.html";
                } else if (role === "attendee") {
                    window.location.href = "attendee.html";
                } else if (role === "guest") {
                    window.location.href = "guest.html";
                } else {
                    window.location.href = "index.html";
                }
            } else {
                const msg = document.getElementById("message");
                msg.textContent = "❌ Invalid email or password for selected role.";
                msg.style.color = "red";
            }
        });

        return;
    }

    // REDIRECT IF NOT LOGGED IN
    const isLoggedIn = localStorage.getItem("loggedIn");
    if (!isLoggedIn) {
        window.location.href = "index.html";
        return;
    }

    const createEventButton = document.getElementById("createEvent");
    const eventCreationSection = document.getElementById("eventCreation");
    const eventForm = document.getElementById("eventForm");
    const guestList = document.getElementById("guestList");
    const addGuestButton = document.getElementById("addGuest");
    const clearEventsButton = document.getElementById("clearEvents");
    const eventList = document.getElementById("eventList");
    const logoutButton = document.getElementById("logoutButton");
    const editEventButton = document.getElementById("editEvent");

    let guests = [];

    if (logoutButton) {
        logoutButton.addEventListener("click", () => {
            localStorage.removeItem("loggedIn");
            localStorage.removeItem("role");
            window.location.href = "index.html";
        });
    }

    if (createEventButton) {
        createEventButton.addEventListener("click", () => {
            if (eventCreationSection) {
                eventCreationSection.style.display = eventCreationSection.style.display === "none" ? "block" : "none";
            }
        });
    }

    if (addGuestButton) {
        addGuestButton.addEventListener("click", () => {
            const guestInput = document.getElementById("guestName");
            const guestName = guestInput.value.trim();
            if (guestName) {
                guests.push(guestName);
                const li = document.createElement("li");
                li.textContent = guestName;
                guestList.appendChild(li);
                guestInput.value = "";
            }
        });
    }

    if (eventForm) {
        eventForm.addEventListener("submit", function (e) {
            e.preventDefault();

            const type = document.getElementById("eventType").value;
            const date = document.getElementById("eventDate").value;
            const time = document.getElementById("eventTime").value;
            const location = document.getElementById("eventLocation").value;
            const price = document.getElementById("eventPrice").value || 0;
            const tickets = document.getElementById("eventTickets")?.value || 0;
            const description = document.getElementById("eventDescription")?.value || "";

            const event = {
                type,
                date,
                time,
                location,
                price,
                tickets,
                description,
                guests
            };

            saveEvent(event);
            displayEvents();
            eventForm.reset();
            guestList.innerHTML = "";
            guests = [];
            alert("✅ Event Created Successfully!");
        });
    }

    if (clearEventsButton) {
        clearEventsButton.addEventListener("click", () => {
            localStorage.removeItem("events");
            displayEvents();
        });
    }

    if (editEventButton) {
        editEventButton.addEventListener("click", function () {
            const events = JSON.parse(localStorage.getItem("events")) || [];
            if (!events.length) {
                alert("⚠ No events found to edit.");
                return;
            }
            editEvent(events.length - 1);
        });
    }

    function saveEvent(event) {
        let events = JSON.parse(localStorage.getItem("events")) || [];
        events.push(event);
        localStorage.setItem("events", JSON.stringify(events));
    }

    function displayEvents() {
        if (!eventList) return;
        eventList.innerHTML = "";
        const events = JSON.parse(localStorage.getItem("events")) || [];
        events.forEach((event, index) => {
            const li = document.createElement("li");
            li.innerHTML = `
                <strong>${event.type}</strong> - ${event.date} ${event.time}<br>
                📍 ${event.location} | 💲${event.price}<br>
                📝 ${event.description || ""}<br>
                👥 Guests: ${event.guests.join(", ")}<br>
                <button onclick="editEvent(${index})" class="edit-event-btn">Edit</button>
                <button onclick="deleteEvent(${index})">Delete</button>
            `;
            eventList.appendChild(li);
        });
    }

    window.deleteEvent = function (index) {
        let events = JSON.parse(localStorage.getItem("events")) || [];
        events.splice(index, 1);
        localStorage.setItem("events", JSON.stringify(events));
        displayEvents();
    };

    window.editEvent = function (index) {
        let events = JSON.parse(localStorage.getItem("events")) || [];
        const e = events[index];
        document.getElementById("editEventType").value = e.type || "";
        document.getElementById("editEventDate").value = e.date || "";
        document.getElementById("editEventTime").value = e.time || "";
        document.getElementById("editEventLocation").value = e.location || "";
        document.getElementById("editEventPrice").value = e.price || 0;
        document.getElementById("editEventTickets").value = e.tickets || 0;
        document.getElementById("editEventDescription").value = e.description || "";
        document.getElementById("editEventIndex").value = index;
        document.getElementById("editEventModal").style.display = "block";
    };

    document.getElementById("cancelEdit")?.addEventListener("click", function () {
        document.getElementById("editEventModal").style.display = "none";
    });

    document.getElementById("editEventForm")?.addEventListener("submit", function (e) {
        e.preventDefault();
        const index = parseInt(document.getElementById("editEventIndex").value);
        let events = JSON.parse(localStorage.getItem("events")) || [];
        events[index] = {
            ...events[index],
            type: document.getElementById("editEventType").value,
            date: document.getElementById("editEventDate").value,
            time: document.getElementById("editEventTime").value,
            location: document.getElementById("editEventLocation").value,
            price: document.getElementById("editEventPrice").value,
            tickets: document.getElementById("editEventTickets").value,
            description: document.getElementById("editEventDescription").value,
        };
        localStorage.setItem("events", JSON.stringify(events));
        document.getElementById("editEventModal").style.display = "none";
        setTimeout(() => {
            alert("✏ Event Updated!");
            location.reload();
        }, 300);
    });
	
	

    displayEvents();
});

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("inviteForm");
  const statusMessage = document.createElement("p");

  statusMessage.style.color = "lightgreen";
  statusMessage.style.textAlign = "center";
  statusMessage.style.marginTop = "15px";
  statusMessage.style.display = "none";

  form.parentNode.appendChild(statusMessage);

  form.addEventListener("submit", function (e) {
    e.preventDefault(); // prevent actual form submission
	
	document.getElementById("checkWeatherBtn").addEventListener("click", function() {
  // some code
});


    // Simulate processing delay (like sending data to a server)
    setTimeout(() => {
      statusMessage.textContent = "🎉 Invitations Sent Successfully!";
      statusMessage.style.display = "block";
      form.reset(); // optional: reset the form fields
    }, 1000);
  });
});

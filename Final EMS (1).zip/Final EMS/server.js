const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const nodemailer = require("nodemailer");
const csv = require("csv-parser");
require("dotenv").config();

const app = express();
const PORT = 3000;

const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  }
});
const upload = multer({ storage });

app.use(express.static(__dirname));
app.use(express.urlencoded({ extended: true }));

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  }
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "invite.html"));
});

app.post("/send-invites", upload.fields([{ name: "emailFile" }, { name: "inviteFile" }]), (req, res) => {
  const emailCSVPath = req.files["emailFile"][0].path;
  const invitePath = req.files["inviteFile"][0].path;
  const inviteName = req.files["inviteFile"][0].originalname;
  const message = req.body.message;

  const emails = [];

  fs.createReadStream(emailCSVPath)
    .pipe(csv())
    .on("data", (row) => {
      const email = Object.values(row)[0];
      emails.push(email);
    })
    .on("end", () => {
      emails.forEach((email) => {
        const mailOptions = {
          from: process.env.EMAIL_USER,
          to: email,
          subject: "You're Invited!",
          text: message,
          attachments: [
            {
              filename: inviteName,
              path: invitePath
            }
          ]
        };

        transporter.sendMail(mailOptions, (error, info) => {
          if (error) {
            console.error(`❌ Failed to send to ${email}:`, error);
          } else {
            console.log(`✅ Sent to ${email}: ${info.response}`);
          }
        });
      });

      res.send("✅ Invitations sent to all emails in the list!");
    });
});

app.listen(PORT, () => {
  console.log(`✅ Server is running at http://localhost:${PORT}`);
});
